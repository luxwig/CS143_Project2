Since this project is a relatively small-scaled project. Two of us finish the project together
