Two of us finish the project together
